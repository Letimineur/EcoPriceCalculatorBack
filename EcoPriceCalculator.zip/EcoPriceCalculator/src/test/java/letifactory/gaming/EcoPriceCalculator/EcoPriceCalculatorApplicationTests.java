package letifactory.gaming.EcoPriceCalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoPriceCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
